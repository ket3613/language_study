package com.example.affirmations.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.affirmations.R
import com.example.affirmations.model.Affirmation

// ItemAdapter 에서 지금이 mainActivity정보와 List에 표연할 정보를 가져온다
// 반환은 RecyclerView.Adapter <ItemAdapter.ItemViewHolder>() 함수를 반환한다.
class ItemAdapter(
    private val context: Context,
    private val dataset: List<Affirmation>
): RecyclerView.Adapter<ItemAdapter.ItemViewHolder>() {

    //내부 클래스 들어온 뷰값을 가지고 Id연결
    class ItemViewHolder(private val view: View): RecyclerView.ViewHolder(view) {
        val textView: TextView = view.findViewById(R.id.item_title)
        val imageView: ImageView = view.findViewById(R.id.item_image)
    }

    /**
     * 새로운 보기만들기 (레이아웃 관리자에 의해 자동으로 실행됨)
     */
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        // 새로운 view만들기
        val adapterLayout = LayoutInflater.from(parent.context)
            .inflate(R.layout.list_item, parent, false)

        return ItemViewHolder(adapterLayout)
    }

    /**
     * 보기에 내용 바꾸기 (레이아웃 관리자에 의해 자동으로 실행됨)
     */
    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val item = dataset[position]
        holder.textView.text = context.resources.getString(item.stringResourceId)
        holder.imageView.setImageResource(item.imageResourceId)
    }

    /**
     * 데이터 세트의 크기를 반환합니다(레이아웃 관리자에서 호출).
     */
    override fun getItemCount() = dataset.size
}