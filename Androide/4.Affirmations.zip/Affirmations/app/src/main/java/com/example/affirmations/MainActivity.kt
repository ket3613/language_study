package com.example.affirmations

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.affirmations.adapter.ItemAdapter
import com.example.affirmations.data.Datasource

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Datasource 클래스에서 List정보를 불러오는 loadAffirmations()함수 사용
        // myDataset 변수에 담기
        // 1. 이미 정의된 문구와 이미지를 매핑해주고 담아놓은다.
        val myDataset = Datasource().loadAffirmations()

        // 1. recyclerView 에 ID 를 가져온다
        val recyclerView = findViewById<RecyclerView>(R.id.recycler_view)

        //데이터 정보를 갖고 view를 다시 만들고 새로 보기넣기등 동작
        recyclerView.adapter = ItemAdapter(this, myDataset)
        // 변경 사항을 알고 있는 경우 이 설정을 사용하여 성능을 향상시킵니다.
        // 내용에서 RecyclerView의 레이아웃 크기를 변경하지 않음
        recyclerView.setHasFixedSize(true)
    }
}