package com.example.tipcalculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.example.tipcalculator.databinding.ActivityMainBinding
import java.text.NumberFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    //객체를 하나씩 호출하는게 아니라 한번에 호출하기위한 방법 바인딩
    lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //바인딩을 통한 calculateButton 을 누르면 calculateTip 메소드(함수)를 진행한다.
        binding.calculateButton.setOnClickListener { calculateTip() }

    }

    private fun calculateTip() {
        val stringInTextField = binding.costOfService.text.toString()
        //toDoubleOrNull() 함수는 더블타입 아니면 null이라는 함수이다.
        val cost = stringInTextField.toDoubleOrNull()
        //결국 입력값이 비정상적이여서 null인경우
        if (cost == null) {
            //반환값 보여주는곳에 빈값 출력
            binding.tipResult.text = ""
            return
        }

        //모든 라디오 그룹에 있는 라디오버튼 값중 고른값을 요율 tipPercentage넣기
       val tipPercentage = when (binding.tipOptions.checkedRadioButtonId) {
            R.id.option_twenty_percent -> 0.20
            R.id.option_eighteen_percent -> 0.18
            else -> 0.15
        }

        //tipPercentage 넣은 값과 입력한 값을 곱한다.
        var tip = tipPercentage * cost
        //만약 올림을 위한 스위치 버튼이 체크되어있으면
        if (binding.roundUpSwitch.isChecked) {
            //kotlin.math.ceil() 소수점 올림
            tip = kotlin.math.ceil(tip)
        }

        //나온 결과값을 NumberFormat으로 각 나라,폰 설정에 맞는 통화로 변경
        val formattedTip = NumberFormat.getCurrencyInstance(Locale.KOREA).format(tip)
        //나온값을 tip출력에 보이기 첫번째 인수에 StringFormat을 가져온다 %s.. 그리고 가져온 패턴만큼 인자값을 추가한다.
        binding.tipResult.text = getString(R.string.tip_amount,formattedTip)
    }
}