package com.example.diceapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val diceVar = Dice(2)
        val diceVar2 = Dice(10)


        val rollButton: Button = findViewById(R.id.diceBtn1)
        rollButton.setOnClickListener {

            val resultTextView: TextView = findViewById(R.id.textView)
            resultTextView.text = diceVar.DiceRoll().toString()

            print("Dice 눈금= ${diceVar.parameterInt} diceRoll 주사위 굴린값 ${diceVar.DiceRoll()}")
        }

        val rollButton2: Button = findViewById(R.id.diceBtn2)
        rollButton2.setOnClickListener {

            val resultTextView: TextView = findViewById(R.id.textView)
            resultTextView.text = diceVar2.DiceRoll().toString()

            print("Dice 눈금= ${diceVar2.parameterInt} diceRoll 주사위 굴린값 ${diceVar2.DiceRoll()}")
        }

    }
}

class Dice (val parameterInt:Int){

    fun DiceRoll(): Int{
        return (1..parameterInt).random()
    }
}