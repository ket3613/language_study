/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and 
 * limitations under the License.
 */

package com.example.android.unscramble.ui.game

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.example.android.unscramble.R
import com.example.android.unscramble.databinding.GameFragmentBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/**
 * Fragment where the game is played, contains the game logic.
 */
class GameFragment : Fragment() {

    // game_fragment.xml 레이아웃의 뷰에 대한 액세스 권한이 있는 바인딩 개체 인스턴스
    private lateinit var binding: GameFragmentBinding

    // 프래그먼트가 처음 생성될 때 ViewModel을 생성합니다.
    // 프래그먼트가 다시 생성되면 프래그먼트가 생성한 동일한 GameViewModel 인스턴스를 수신합니다.
    // 첫 번째 조각.
    private val viewModel: GameViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // 레이아웃 XML 파일을 확장하고 바인딩 개체 인스턴스를 반환합니다.
        // #프레그먼트를 사용하기 위한 등록 부분!
        binding = DataBindingUtil.inflate(inflater, R.layout.game_fragment, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // 프래그 먼트에서 사용되는 값 정의 및 초기화
        binding.gameViewModel = viewModel
        binding.maxNoOfWords = MAX_NO_OF_WORDS

        // 프래그먼트 뷰를 바인딩의 수명 주기 소유자로 지정합니다.
        // 바인딩이 LiveData 업데이트를 관찰할 수 있도록 사용
        binding.lifecycleOwner = viewLifecycleOwner

        // 제출 및 건너뛰기 버튼에 대한 클릭 리스너를 설정합니다.
        binding.submit.setOnClickListener { onSubmitWord() }
        binding.skip.setOnClickListener { onSkipWord() }
    }

    /*
    * 사용자의 단어를 확인하고 그에 따라 점수를 업데이트합니다.
    * 다음 스크램블된 단어를 표시합니다.
    * 마지막 단어 후에 최종 점수가 포함된 대화 상자가 사용자에게 표시됩니다.
    */
    private fun onSubmitWord() {
        val playerWord = binding.textInputEditText.text.toString()


        //viewModel에서 함수를 통해서 비교후 맞으면 viewModel에 점수 증가
        if (viewModel.isUserWordCorrect(playerWord)) {
            setErrorTextField(false)
            if (!viewModel.nextWord()) {
                showFinalScoreDialog()
            }
        } else {
            setErrorTextField(true)
        }
    }

    /*
    * 점수를 변경하지 않고 현재 단어를 건너뜁니다.
    * 단어 수를 늘립니다.
    * 마지막 단어 후에 최종 점수가 포함된 대화 상자가 사용자에게 표시됩니다.
    */
    private fun onSkipWord() {
        if (viewModel.nextWord()) {
            setErrorTextField(false)
        } else {
            showFinalScoreDialog()
        }
    }

    /*
     * 최종 점수와 함께 AlertDialog를 만들고 표시합니다.
     */
    private fun showFinalScoreDialog() {
        MaterialAlertDialogBuilder(requireContext())
                .setTitle(getString(R.string.congratulations))
                .setMessage(getString(R.string.you_scored, viewModel.score.value))
                .setCancelable(false)
                .setNegativeButton(getString(R.string.exit)) { _, _ ->
                    exitGame()
                }
                .setPositiveButton(getString(R.string.play_again)) { _, _ ->
                    restartGame()
                }
                .show()
    }

    /*
     * ViewModel의 데이터를 다시 초기화하고 뷰를 새 데이터로 업데이트하여
     * 게임을 다시 시작합니다.
     */
    private fun restartGame() {
        viewModel.reinitializeData()
        setErrorTextField(false)
    }

    /*
     * 게임을 종료합니다.
     */
    private fun exitGame() {
        activity?.finish()
    }

    /*
    * 텍스트 필드 오류 상태를 설정 및 재설정합니다.
    */
    private fun setErrorTextField(error: Boolean) {
        if (error) {
            binding.textField.isErrorEnabled = true
            binding.textField.error = getString(R.string.try_again)
        } else {
            binding.textField.isErrorEnabled = false
            binding.textInputEditText.text = null
        }
    }
}
